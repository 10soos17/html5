package p03.console;

public class ConsoleEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
