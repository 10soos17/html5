package p05.secondary_stream;

public class OutputStreamWriterExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
