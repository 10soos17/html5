package p04.fileIO;

public class FileExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
