package p07.enums;

public enum Season {

	SPRING, SUMMER, FALL, WINTER
}
